# macOS

> 1.下载完成，运行 ShadowsocksX，会提示如图，点击「好」；

![mac-01](https://xfgss.com/help/images/mac/mac-01.png)

> 2.打开「系统偏好设置」，点击「安全性与隐私」；

![mac-02](https://xfgss.com/help/images/mac/mac-02.png)

> 3.点击左下角的小锁图标，然后提示输入密码进行解锁；

![mac-03](https://xfgss.com/help/images/mac/mac-03.png)

> 4.选择「允许任何来源」；

![mac-04](https://xfgss.com/help/images/mac/mac-04.png)

> 5.再次运行 ShadowsocksX 程序，点击「打开」；

![mac-05](https://xfgss.com/help/images/mac/mac-05.png)

> 6.在网站用户中心里，复制节点订阅链接；

![mac-06](https://xfgss.com/help/images/mac/mac-06.png)

> 7.点击任务栏的小飞机，点击「服务器」-「打开时自动更新订阅」；

![mac-07](https://xfgss.com/help/images/mac/mac-07.png)

> 8.点击任务栏的小飞机，点击「服务器」-「编辑订阅」；

![mac-08](https://xfgss.com/help/images/mac/mac-08.png)

> 9.点击左下角「＋」，然后粘贴节点订阅链接到「订阅地址」中，并在「组名」中填写备注；

![mac-09](https://xfgss.com/help/images/mac/mac-09.png)

> 10.最后就可以选择一个节点进行科学上网啦。

![mac-10](https://xfgss.com/help/images/mac/mac-10.png)