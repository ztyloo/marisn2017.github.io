# Android

> 1.在网站用户中心里，复制节点订阅链接；

![android-01](https://xfgss.com/help/images/android/android-01.png)

> 2.打开 Shadowsocks，点击左上角「ShadowsocksR ▼」；

![android-02](https://xfgss.com/help/images/android/android-02.png)

> 3.划动移除默认节点配置；

![android-03](https://xfgss.com/help/images/android/android-03.png)

> 4.点击右下角「+」，选择「添加/升级 SSR 订阅」；

![android-04](https://xfgss.com/help/images/android/android-04.png)

> 5.划动删除默认订阅链接；

![android-05](https://xfgss.com/help/images/android/android-05.png)

> 6.选择「直接删除」；

![android-06](https://xfgss.com/help/images/android/android-06.png)

> 7.点击「添加订阅地址」；

![android-07](https://xfgss.com/help/images/android/android-07.png)

> 8.粘贴节点订阅链接，点击「确定」；

![android-08](https://xfgss.com/help/images/android/android-08.png)

> 9.打开自动更新，点击「确定并升级」；

![android-09](https://xfgss.com/help/images/android/android-09.png)

> 10.在节点列表中，点击闪电图标检测节点延迟，然后点击一个低延迟的节点；

![android-10](https://xfgss.com/help/images/android/android-10.png)

> 11.下划找到「功能设置」-「路由」，把「全局」更换为「绕过中国大陆地址」；

![android-11](https://xfgss.com/help/images/android/android-11.png)

> 12.点击右上角小飞机图标启动代理；

![android-12](https://xfgss.com/help/images/android/android-12.png)

> 12.首次启动会弹出一个“网络连接请求”，点击「确定」后就可以科学上网啦。

![android-12](https://xfgss.com/help/images/android/android-12.png)