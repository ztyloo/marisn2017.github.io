# Windows

> 1.安装完成后，打开 SSTap，点击 「设置」-「SSR订阅」-「SSR订阅管理...」；

![win-01](https://xfgss.com/help/images/windows/win-01.png)

> 2.在网站用户中心里，复制节点订阅链接；

![win-02](https://xfgss.com/help/images/windows/win-02.png)

> 3.粘贴节点订阅链接至「URL」中，点击「添加」，然后关闭返回到主界面；

![win-02](https://xfgss.com/help/images/windows/win-03.png)

> 4.选择一个延迟较低的节点；

![win-04](https://xfgss.com/help/images/windows/win-04.png)

> 5.「模式」一般选择「仅网页浏览器（跳过中国站点）」，适合日常上网，如不能使用，则切换「全局」即可；

![win-05](https://xfgss.com/help/images/windows/win-05.png)

> 6.最后点击「连接」即可科学上网。

![win-06](https://xfgss.com/help/images/windows/win-06.png)