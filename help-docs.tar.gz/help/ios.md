# iOS

> 1.Shadowrocket 安装完成后，使用网页提供的帐号密码登录授权；

![ios-01](https://xfgss.com/help/images/ios/ios-01.png)

> 2.在网站用户中心里，复制节点订阅链接；

![ios-02](https://xfgss.com/help/images/ios/ios-02.png)

> 3.打开 Shadowrocket，点击「添加节点」；

![ios-03](https://xfgss.com/help/images/ios/ios-03.png)

> 4.类型选择「Subscribe」，粘贴节点订阅链接至「URL」中，并填写好「备注」，点击右上角「完成」；

![ios-04](https://xfgss.com/help/images/ios/ios-04.png)

> 5.点击右下角「设置」，找到并点击「服务器订阅」；

![ios-05](https://xfgss.com/help/images/ios/ios-05.png)

> 6.开启「打开时更新」选项；

![ios-06](https://xfgss.com/help/images/ios/ios-06.png)

> 7.返回到首页，点击「延迟测试」，选择一个低延迟的节点（多点几下）；

![ios-07](https://xfgss.com/help/images/ios/ios-07.png)

> 8.启动代理，首次启动会提示“Shadowrocket 想要添加 VPN 配置”，点击「Allow」后验证密码，最后即可科学上网。

![ios-08](https://xfgss.com/help/images/ios/ios-08.png)